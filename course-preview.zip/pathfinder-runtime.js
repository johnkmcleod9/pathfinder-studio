/* Pathfinder Browser Runtime */
(function(global) {
  'use strict';

  function PathfinderRuntime(opts) {
    opts = opts || {};
    this.course = opts.course || {};
    this.container = opts.container;
    this.lmsAdapter = opts.lmsAdapter || null;
    this.listeners = {};
    this.variables = {};
    this.currentIndex = 0;
    this.currentSlideEl = null;

    // Quiz state — answers buffered per question until submitQuiz is fired.
    this.quizAnswers = {};
    this.lastQuizScore = null;
    this.quizAttemptCount = 0;

    var nav = this.course.navigation || {};
    this.slideIds = (nav.slides || []).slice();
    if (nav.entry) {
      var idx = this.slideIds.indexOf(nav.entry);
      this.currentIndex = idx >= 0 ? idx : 0;
    }

    // Initialize variable store from declared defaults.
    var vars = this.course.variables || {};
    for (var name in vars) {
      if (Object.prototype.hasOwnProperty.call(vars, name)) {
        var v = vars[name];
        this.variables[name] = (v && 'default' in v) ? v.default : null;
      }
    }

    // Per-slide layer visibility — keyed by slide id, value is a map of
    // layerId → bool.  Reset whenever we enter a slide so layers return
    // to their declared initial visibility.
    this.layerVisibility = {};

    // Session-time tracking — start the clock the moment the runtime
    // is constructed (not at start()) so a learner who downloads the
    // package and watches it slow-load still gets credit for the wait.
    this.sessionStartTime = Date.now();
    this.terminated = false;

    // Auto-completion bookkeeping. completed=true once SaveCompletion
    // has been pushed (either via reaching the last slide on an
    // info-only course or via quiz submission); guards against
    // duplicate writes / re-emits.
    this.completed = false;

    // Build a question lookup so quiz objects can resolve their question by id.
    this.questionsById = {};
    var quiz = this.course.quiz;
    if (quiz && quiz.questions) {
      for (var qi = 0; qi < quiz.questions.length; qi++) {
        var qq = quiz.questions[qi];
        if (qq && qq.id) this.questionsById[qq.id] = qq;
      }
    }
  }

  // ---- Lifecycle ----

  PathfinderRuntime.prototype.start = function() {
    this._restoreFromLms();
    this._renderCurrentSlide();
    this._emit('slidechange', this.getCurrentSlideId(), this.currentIndex, this.slideIds.length);
    this._maybeAutoComplete();
    this._bindKeyboard();
  };

  // ---- Keyboard navigation ----

  // WCAG 2.1 AA requires keyboard operability. We bind on document so
  // the listener works regardless of focus position. A course author
  // can opt out via course.navigation.keyboard === false.
  PathfinderRuntime.prototype._bindKeyboard = function() {
    var nav = this.course.navigation || {};
    if (nav.keyboard === false) return;
    if (this._keyboardHandler) return; // already bound
    var self = this;
    this._keyboardHandler = function(e) {
      // Skip when the user is typing in an editable field — quiz
      // fill-in inputs need arrow keys for cursor movement.
      var t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' ||
                t.isContentEditable)) {
        return;
      }
      switch (e.key) {
        case 'ArrowRight':
        case 'PageDown':
        case ' ':
          self.navigateNext();
          break;
        case 'ArrowLeft':
        case 'PageUp':
          self.navigatePrev();
          break;
        case 'Home':
          self._goToIndex(0);
          break;
        case 'End':
          self._goToIndex(self.slideIds.length - 1);
          break;
        default:
          return;
      }
      e.preventDefault();
    };
    if (typeof document !== 'undefined') {
      document.addEventListener('keydown', this._keyboardHandler);
    }
  };

  PathfinderRuntime.prototype._unbindKeyboard = function() {
    if (this._keyboardHandler && typeof document !== 'undefined') {
      document.removeEventListener('keydown', this._keyboardHandler);
    }
    this._keyboardHandler = null;
  };

  // Helper used by Home / End. Skips re-emit when target == current.
  PathfinderRuntime.prototype._goToIndex = function(idx) {
    if (idx < 0 || idx >= this.slideIds.length) return;
    if (idx === this.currentIndex) return;
    this._resetLayerVisibility(this.getCurrentSlideId());
    this.currentIndex = idx;
    this._renderCurrentSlide();
    this._persistLocation();
    this._emit('slidechange', this.getCurrentSlideId(), this.currentIndex, this.slideIds.length);
    this._maybeAutoComplete();
  };

  // ---- Auto-completion ----

  PathfinderRuntime.prototype.isComplete = function() {
    return this.completed === true;
  };

  // Mark the course complete the first time the learner reaches the
  // last slide of an info-only course (no quiz). Quiz courses leave
  // completion to the quizcomplete path so we don't overwrite the
  // pass/fail verdict.
  PathfinderRuntime.prototype._maybeAutoComplete = function() {
    if (this.completed) return;
    if (this.course.quiz) return; // quiz drives completion separately
    if (this.currentIndex !== this.slideIds.length - 1) return;
    this._markComplete();
  };

  PathfinderRuntime.prototype._markComplete = function() {
    if (this.completed) return;
    this.completed = true;
    if (this.lmsAdapter && typeof this.lmsAdapter.SaveCompletion === 'function') {
      try {
        this.lmsAdapter.SaveCompletion('completed');
      } catch (e) {
        if (typeof console !== 'undefined' && console.warn) {
          console.warn('[PathfinderRuntime] SaveCompletion threw:', e);
        }
      }
    }
    this._emit('coursecomplete', { slideId: this.getCurrentSlideId() });
  };

  // ---- Resume / suspend-data ----

  PathfinderRuntime.prototype._restoreFromLms = function() {
    if (!this.lmsAdapter || typeof this.lmsAdapter.LoadSuspendData !== 'function') return;
    var state;
    try {
      state = this.lmsAdapter.LoadSuspendData();
    } catch (e) {
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[PathfinderRuntime] LoadSuspendData threw:', e);
      }
      return;
    }
    if (!state || typeof state !== 'object') return;

    // Restore current slide if it still exists in the course.
    if (typeof state.slide === 'string') {
      var idx = this.slideIds.indexOf(state.slide);
      if (idx >= 0) this.currentIndex = idx;
    }

    // Restore variable values (overrides declared defaults).
    if (state.variables && typeof state.variables === 'object') {
      for (var k in state.variables) {
        if (Object.prototype.hasOwnProperty.call(state.variables, k)) {
          this.variables[k] = state.variables[k];
        }
      }
    }

    // Restore last quiz score so re-entering shows the prior result.
    if (state.lastQuizScore && typeof state.lastQuizScore === 'object') {
      this.lastQuizScore = state.lastQuizScore;
    }

    // Restore quiz attempt count so attempt limits hold across sessions.
    if (typeof state.quizAttemptCount === 'number') {
      this.quizAttemptCount = state.quizAttemptCount;
    }
  };

  PathfinderRuntime.prototype.saveProgress = function() {
    if (!this.lmsAdapter || typeof this.lmsAdapter.SaveSuspendData !== 'function') return;
    var snapshot = {
      _v: 1,
      slide: this.getCurrentSlideId(),
      variables: this.variables,
      lastQuizScore: this.lastQuizScore,
      quizAttemptCount: this.quizAttemptCount,
    };
    try {
      this.lmsAdapter.SaveSuspendData(snapshot);
    } catch (e) {
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[PathfinderRuntime] SaveSuspendData threw:', e);
      }
    }
  };

  PathfinderRuntime.prototype._persistLocation = function() {
    if (!this.lmsAdapter) return;
    if (typeof this.lmsAdapter.SaveLocation === 'function') {
      try { this.lmsAdapter.SaveLocation(this.getCurrentSlideId()); } catch (e) {
        if (typeof console !== 'undefined' && console.warn) {
          console.warn('[PathfinderRuntime] SaveLocation threw:', e);
        }
      }
    }
    this.saveProgress();
  };

  // ---- Navigation ----

  PathfinderRuntime.prototype.navigateNext = function() {
    if (this.currentIndex < this.slideIds.length - 1) {
      this._resetLayerVisibility(this.getCurrentSlideId());
      this.currentIndex++;
      this._renderCurrentSlide();
      this._persistLocation();
      this._emit('slidechange', this.getCurrentSlideId(), this.currentIndex, this.slideIds.length);
      this._maybeAutoComplete();
    }
  };

  PathfinderRuntime.prototype.navigatePrev = function() {
    if (this.currentIndex > 0) {
      this._resetLayerVisibility(this.getCurrentSlideId());
      this.currentIndex--;
      this._renderCurrentSlide();
      this._persistLocation();
      this._emit('slidechange', this.getCurrentSlideId(), this.currentIndex, this.slideIds.length);
    }
  };

  // ---- Session time / termination ----

  PathfinderRuntime.prototype.getSessionTime = function() {
    return Date.now() - this.sessionStartTime;
  };

  // Push final state to the LMS and end the session. Idempotent —
  // a second call is a no-op so accidental double-bind on browser
  // unload doesn't double-write.
  PathfinderRuntime.prototype.terminate = function() {
    if (this.terminated) return;
    this.terminated = true;

    var elapsedMs = this.getSessionTime();

    // Detach DOM listeners before pushing final state so a duplicate
    // keypress mid-terminate can't trigger more navigation.
    this._unbindKeyboard();

    // Flush latest state first so the suspend payload reflects the
    // exact moment of exit.
    this.saveProgress();

    if (this.lmsAdapter) {
      if (typeof this.lmsAdapter.SaveSessionTime === 'function') {
        try { this.lmsAdapter.SaveSessionTime(elapsedMs); } catch (e) {
          if (typeof console !== 'undefined' && console.warn) {
            console.warn('[PathfinderRuntime] SaveSessionTime threw:', e);
          }
        }
      }
      if (typeof this.lmsAdapter.Terminate === 'function') {
        try { this.lmsAdapter.Terminate(''); } catch (e) {
          if (typeof console !== 'undefined' && console.warn) {
            console.warn('[PathfinderRuntime] Terminate threw:', e);
          }
        }
      }
    }

    this._emit('sessionend', { durationMs: elapsedMs });
  };

  PathfinderRuntime.prototype.getCurrentSlideId = function() {
    return this.slideIds[this.currentIndex];
  };

  PathfinderRuntime.prototype._getSlide = function(id) {
    var slides = this.course.slides || [];
    for (var i = 0; i < slides.length; i++) {
      if (slides[i] && slides[i].id === id) return slides[i];
    }
    return null;
  };

  // ---- Variables ----

  PathfinderRuntime.prototype.getVariable = function(name) {
    return this.variables[name];
  };

  PathfinderRuntime.prototype.setVariable = function(name, value) {
    var prev = this.variables[name];
    this.variables[name] = value;
    if (prev !== value) {
      this._pushVarToLms(name, value);
    }
    this.saveProgress();
    // Variable change may flip an object's conditional visibility.
    // Cheap correctness win: re-render whenever a value actually
    // changed. (No-op when the same value is re-set.)
    if (prev !== value && this.currentSlideEl) {
      this._renderCurrentSlide();
    }
  };

  // Push a single variable value to the LMS gradebook when the
  // course author has opted in (exportToLMS=true + lmsMapping.key).
  // No-ops gracefully when adapter is missing or lacks SetValue.
  PathfinderRuntime.prototype._pushVarToLms = function(name, value) {
    var vars = this.course.variables || {};
    var def = vars[name];
    if (!def || !def.exportToLMS) return;
    if (!def.lmsMapping || !def.lmsMapping.key) return;
    if (!this.lmsAdapter || typeof this.lmsAdapter.SetValue !== 'function') return;

    // SCORM data model values are strings — coerce via String() so
    // booleans become 'true'/'false' and numbers become decimal strings.
    var serialized = (value === null || value === undefined) ? '' : String(value);
    try {
      this.lmsAdapter.SetValue(def.lmsMapping.key, serialized);
      if (typeof this.lmsAdapter.Commit === 'function') {
        this.lmsAdapter.Commit('');
      }
    } catch (e) {
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[PathfinderRuntime] LMS push failed for ' + name + ':', e);
      }
    }
  };

  // ---- Pub/sub ----

  PathfinderRuntime.prototype.on = function(event, cb) {
    if (typeof cb !== 'function') return;
    if (!this.listeners[event]) this.listeners[event] = [];
    this.listeners[event].push(cb);
  };

  PathfinderRuntime.prototype.off = function(event, cb) {
    var arr = this.listeners[event];
    if (!arr) return;
    var idx = arr.indexOf(cb);
    if (idx >= 0) arr.splice(idx, 1);
  };

  PathfinderRuntime.prototype._emit = function(event /*, ...args */) {
    var args = Array.prototype.slice.call(arguments, 1);
    var subs = (this.listeners[event] || []).slice();
    for (var i = 0; i < subs.length; i++) {
      try { subs[i].apply(null, args); } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
          console.error('[PathfinderRuntime] listener for "' + event + '" threw:', e);
        }
      }
    }
  };

  // ---- Rendering ----

  PathfinderRuntime.prototype._renderCurrentSlide = function() {
    if (!this.container) return;

    if (this.currentSlideEl && this.currentSlideEl.parentNode) {
      this.currentSlideEl.parentNode.removeChild(this.currentSlideEl);
    }
    this.currentSlideEl = null;

    var slide = this._getSlide(this.getCurrentSlideId());
    if (!slide) return;

    var canvas = this.course.canvas || { width: 1280, height: 720 };
    var wrapper = document.createElement('div');
    wrapper.setAttribute('data-slide-id', slide.id);
    wrapper.className = 'pf-slide';
    wrapper.style.position = 'relative';
    wrapper.style.width = canvas.width + 'px';
    wrapper.style.height = canvas.height + 'px';
    wrapper.style.overflow = 'hidden';
    wrapper.style.background = this._renderBackground(slide.background);
    // ARIA: announce the slide as a labelled live region so a screen
    // reader user knows where they are after each navigation.
    wrapper.setAttribute('role', 'region');
    wrapper.setAttribute('aria-live', 'polite');
    var slideTitle = slide.title || slide.id;
    wrapper.setAttribute('aria-label',
      'Slide ' + (this.currentIndex + 1) + ' of ' + this.slideIds.length + ': ' + slideTitle);

    var objects = slide.objects || [];
    for (var i = 0; i < objects.length; i++) {
      var el = this._renderObject(objects[i]);
      if (el) wrapper.appendChild(el);
    }

    // Render each currently-visible layer's objects on top of the base.
    var slideLayerVis = this._slideLayerVisibility(slide);
    var layers = slide.layers || [];
    for (var li = 0; li < layers.length; li++) {
      var layer = layers[li];
      if (!layer || !slideLayerVis[layer.id]) continue;
      var layerObjects = layer.objects || [];
      for (var lj = 0; lj < layerObjects.length; lj++) {
        var lel = this._renderObject(layerObjects[lj]);
        if (lel) {
          lel.setAttribute('data-layer-id', layer.id);
          wrapper.appendChild(lel);
        }
      }
    }

    this._attachTriggerListeners(wrapper, slide);

    this.container.appendChild(wrapper);
    this.currentSlideEl = wrapper;
  };

  // ---- Layers ----

  // Per-slide layer visibility map. Lazily seeded from each layer's
  // declared visible flag the first time the slide is rendered.
  // Reset on slide navigation (see _resetLayerVisibility) so layers
  // return to their declared initial state on re-entry.
  PathfinderRuntime.prototype._slideLayerVisibility = function(slide) {
    var sid = slide.id;
    if (!this.layerVisibility[sid]) {
      this.layerVisibility[sid] = {};
      var layers = slide.layers || [];
      for (var i = 0; i < layers.length; i++) {
        if (layers[i] && layers[i].id) {
          this.layerVisibility[sid][layers[i].id] = layers[i].visible !== false;
        }
      }
    }
    return this.layerVisibility[sid];
  };

  PathfinderRuntime.prototype.isLayerVisible = function(layerId) {
    var slide = this._getSlide(this.getCurrentSlideId());
    if (!slide) return false;
    var vis = this._slideLayerVisibility(slide);
    return vis[layerId] === true;
  };

  PathfinderRuntime.prototype.showLayer = function(layerId) {
    this._setLayerVisibility(layerId, true);
  };

  PathfinderRuntime.prototype.hideLayer = function(layerId) {
    this._setLayerVisibility(layerId, false);
  };

  // Forget the visibility map for a slide so the next entry re-seeds
  // from the declared visible flags. Called when navigating away.
  PathfinderRuntime.prototype._resetLayerVisibility = function(slideId) {
    if (slideId && this.layerVisibility[slideId]) {
      delete this.layerVisibility[slideId];
    }
  };

  PathfinderRuntime.prototype._setLayerVisibility = function(layerId, visible) {
    var slide = this._getSlide(this.getCurrentSlideId());
    if (!slide) return;
    var layers = slide.layers || [];
    var found = false;
    for (var i = 0; i < layers.length; i++) {
      if (layers[i] && layers[i].id === layerId) { found = true; break; }
    }
    if (!found) return;
    var vis = this._slideLayerVisibility(slide);
    if (vis[layerId] === visible) return;
    vis[layerId] = visible;
    this._renderCurrentSlide();
  };

  PathfinderRuntime.prototype._renderBackground = function(bg) {
    if (!bg) return '#FFFFFF';
    if (bg.type === 'solid') return bg.color || '#FFFFFF';
    if (bg.type === 'gradient' && bg.stops && bg.stops.length) {
      var angle = bg.angle != null ? bg.angle : 90;
      var stops = bg.stops.map(function(s) {
        return s.color + (s.offset != null ? ' ' + (s.offset * 100) + '%' : '');
      }).join(', ');
      return 'linear-gradient(' + angle + 'deg, ' + stops + ')';
    }
    return '#FFFFFF';
  };

  PathfinderRuntime.prototype._renderObject = function(obj) {
    if (!obj || !obj.rect) return null;
    if (!this._isObjectVisible(obj)) return null;
    var x = obj.rect[0], y = obj.rect[1], w = obj.rect[2], h = obj.rect[3];
    var content = this._substitute(obj.content == null ? '' : String(obj.content));
    var el;

    switch (obj.type) {
      case 'text':
        el = document.createElement('div');
        el.innerHTML = content;
        break;
      case 'button':
        el = document.createElement('button');
        el.textContent = content;
        if (content) el.setAttribute('aria-label', content);
        break;
      case 'image':
        if (!obj.src) {
          el = this._buildMediaFallback(obj, 'image', false);
          break;
        }
        el = document.createElement('img');
        el.setAttribute('src', obj.src);
        el.setAttribute('alt', obj.altText || '');
        el.setAttribute('loading', 'lazy');
        this._wireMediaError(el, obj, 'image');
        break;
      case 'video':
        if (!obj.src) {
          el = this._buildMediaFallback(obj, 'video', false);
          break;
        }
        el = document.createElement('video');
        el.setAttribute('src', obj.src);
        el.setAttribute('controls', '');
        el.setAttribute('preload', 'metadata');
        this._wireMediaError(el, obj, 'video');
        break;
      case 'audio':
        if (!obj.src) {
          el = this._buildMediaFallback(obj, 'audio', false);
          break;
        }
        el = document.createElement('audio');
        el.setAttribute('src', obj.src);
        el.setAttribute('controls', '');
        el.setAttribute('preload', 'metadata');
        this._wireMediaError(el, obj, 'audio');
        break;
      case 'quiz':
        el = this._renderQuizQuestion(obj);
        if (!el) return null;
        break;
      case 'shape':
      default:
        el = document.createElement('div');
        if (content) {
          el.innerHTML = content;
        } else {
          // Pure-decoration shape — hide from screen readers so the
          // user doesn't hear meaningless layout boxes.
          el.setAttribute('aria-hidden', 'true');
        }
    }

    el.setAttribute('data-object-id', obj.id);
    // Tag every rendered object with a stable class so the runtime
    // stylesheet (pathfinder-runtime.css) can provide beautiful
    // defaults per-type. Authors can still override via obj.style,
    // which _applyStyle() writes as inline styles and therefore
    // wins over the class rules.
    var typeClass = 'pf-object pf-object-' + (obj.type || 'unknown');
    el.className = el.className ? (el.className + ' ' + typeClass) : typeClass;
    el.style.position = 'absolute';
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.style.width = w + 'px';
    el.style.height = h + 'px';
    this._applyStyle(el, obj.style || {});

    return el;
  };

  PathfinderRuntime.prototype._applyStyle = function(el, style) {
    if (!style) return;
    if (style.fontSize) el.style.fontSize = style.fontSize + (typeof style.fontSize === 'number' ? 'px' : '');
    if (style.fontFamily) el.style.fontFamily = String(style.fontFamily);
    if (style.fontWeight) el.style.fontWeight = String(style.fontWeight);
    if (style.color) el.style.color = String(style.color);
    if (style.textAlign) el.style.textAlign = String(style.textAlign);
    if (style.backgroundColor) el.style.backgroundColor = String(style.backgroundColor);
    if (style.lineHeight) el.style.lineHeight = String(style.lineHeight);
    if (style.opacity != null) el.style.opacity = String(style.opacity);
  };

  // ---- Media error fallbacks ----

  // Replace a broken <img>/<video>/<audio> with a labelled <div> the
  // moment the browser fires its 'error' event so the learner sees
  // explanatory text instead of a broken-image icon. Also emits a
  // 'mediaerror' event so a host integration can capture diagnostics.
  PathfinderRuntime.prototype._wireMediaError = function(el, obj, kind) {
    var self = this;
    el.addEventListener('error', function() {
      var fallback = self._buildMediaFallback(obj, kind, true);
      // Carry over the data-object-id + data-layer-id + positioning
      // from the original element so layout doesn't shift and the
      // fallback is still findable by selectors that match the
      // original.
      fallback.setAttribute('data-object-id', obj.id);
      var layerId = el.getAttribute('data-layer-id');
      if (layerId) fallback.setAttribute('data-layer-id', layerId);
      fallback.style.position = el.style.position;
      fallback.style.left = el.style.left;
      fallback.style.top = el.style.top;
      fallback.style.width = el.style.width;
      fallback.style.height = el.style.height;
      if (el.parentNode) {
        el.parentNode.replaceChild(fallback, el);
      }
      self._emit('mediaerror', {
        objectId: obj.id,
        type: kind,
        src: obj.src || '',
        altText: obj.altText || '',
      });
    });
  };

  PathfinderRuntime.prototype._buildMediaFallback = function(obj, kind, isError) {
    var div = document.createElement('div');
    var alt = obj.altText || '';
    var label;
    if (isError) {
      label = (kind === 'image' ? 'Image' : kind === 'video' ? 'Video' : 'Audio') + ' not available';
    } else {
      label = alt; // empty-src + alt → render alt alone
    }
    div.textContent = alt ? (label + (isError ? ': ' + alt : '')) : label;
    if (isError) div.setAttribute('data-media-error', 'true');
    // Accessibility: announce as the same media role with an
    // explanatory label so the screen reader still tells the user
    // what they're missing.
    if (kind === 'image') div.setAttribute('role', 'img');
    div.setAttribute('aria-label', alt || label);
    return div;
  };

  PathfinderRuntime.prototype._substitute = function(text) {
    if (!text || typeof text !== 'string') return text;
    var self = this;
    return text.replace(/%([A-Za-z_][A-Za-z0-9_]*)%/g, function(_, name) {
      var v = self.variables[name];
      return v == null ? '' : String(v);
    });
  };

  // ---- Triggers ----

  PathfinderRuntime.prototype._attachTriggerListeners = function(wrapper, slide) {
    var triggers = slide.triggers || [];
    var clickTriggers = {};
    for (var i = 0; i < triggers.length; i++) {
      var t = triggers[i];
      if (!t || !t.event) continue;
      // Source is emitted under event by the compiler (see toRuntimeTrigger).
      // Tolerate a top-level t.source for hand-authored test fixtures.
      var src = (t.event && t.event.source) || t.source;
      if (t.event.type === 'userClick' && src) {
        if (!clickTriggers[src]) clickTriggers[src] = [];
        clickTriggers[src].push(t);
      }
    }
    if (Object.keys(clickTriggers).length === 0) return;

    var self = this;
    wrapper.addEventListener('click', function(e) {
      var target = e.target;
      // walk up to nearest [data-object-id]
      while (target && target !== wrapper) {
        if (target.getAttribute && target.getAttribute('data-object-id')) break;
        target = target.parentNode;
      }
      if (!target || target === wrapper) return;
      var objectId = target.getAttribute('data-object-id');
      var triggered = clickTriggers[objectId] || [];
      for (var j = 0; j < triggered.length; j++) {
        var t = triggered[j];
        if (!self._conditionsPass(t.conditions)) continue;
        self._executeAction(t.action);
      }
    });
  };

  // ---- Trigger condition evaluation ----

  // Returns true when every condition in the array passes (AND).
  // Returns true for missing / empty arrays so triggers without
  // conditions fire unconditionally — preserves backwards
  // compatibility with packages compiled before this change.
  PathfinderRuntime.prototype._conditionsPass = function(conditions) {
    if (!conditions || !conditions.length) return true;
    for (var i = 0; i < conditions.length; i++) {
      if (!this._evalCondition(conditions[i])) return false;
    }
    return true;
  };

  // Evaluate object visibility from its declared shape:
  //   { initial: 'visible'|'hidden', conditional: [{conditions[], then}, ...] }
  // First matching rule wins; falls back to initial when no rule matches.
  // Objects with no visibility field are always visible.
  PathfinderRuntime.prototype._isObjectVisible = function(obj) {
    var v = obj && obj.visibility;
    if (!v) return true;
    var rules = v.conditional || [];
    for (var i = 0; i < rules.length; i++) {
      var rule = rules[i];
      if (this._conditionsPass(rule.conditions)) {
        return rule.then !== 'hidden';
      }
    }
    return v.initial !== 'hidden';
  };

  PathfinderRuntime.prototype._evalCondition = function(cond) {
    if (!cond || !cond.type) return false;
    switch (cond.type) {
      case 'variableEquals': {
        var v = this.variables[cond.variable];
        return v === cond.value;
      }
      case 'variableGreaterThan': {
        var n = Number(this.variables[cond.variable]);
        var t = Number(cond.value);
        if (isNaN(n) || isNaN(t)) return false;
        return n > t;
      }
      case 'variableLessThan': {
        var n2 = Number(this.variables[cond.variable]);
        var t2 = Number(cond.value);
        if (isNaN(n2) || isNaN(t2)) return false;
        return n2 < t2;
      }
      case 'scoreGreaterThan': {
        if (!this.lastQuizScore) return false;
        return this.lastQuizScore.percent > cond.scoreThreshold;
      }
      case 'scoreLessThan': {
        if (!this.lastQuizScore) return false;
        return this.lastQuizScore.percent < cond.scoreThreshold;
      }
      default:
        // Unknown condition type — fail-safe to false so an unrecognised
        // condition cannot silently approve an action.
        return false;
    }
  };

  PathfinderRuntime.prototype._executeAction = function(action) {
    if (!action || !action.type) return;
    switch (action.type) {
      case 'jumpToSlide': {
        var idx = this.slideIds.indexOf(action.target);
        if (idx >= 0) {
          this._resetLayerVisibility(this.getCurrentSlideId());
          this.currentIndex = idx;
          this._renderCurrentSlide();
          this._persistLocation();
          this._emit('slidechange', this.getCurrentSlideId(), this.currentIndex, this.slideIds.length);
          this._maybeAutoComplete();
        }
        return;
      }
      case 'showLayer':
        this.showLayer(action.target);
        return;
      case 'hideLayer':
        this.hideLayer(action.target);
        return;
      case 'setVariable':
        // Compiler emits action.variable per ActionNodeIR. Tolerate
        // action.target as a legacy alias so hand-authored courses
        // written before the shape was codified still drive the runtime.
        this.setVariable(action.variable || action.target, action.value);
        return;
      case 'navigateNext':
        this.navigateNext();
        return;
      case 'navigatePrev':
      case 'navigateBack':
        this.navigatePrev();
        return;
      case 'submitQuiz':
        this._submitQuiz();
        return;
    }
  };

  // ---- Quiz ----

  PathfinderRuntime.prototype.getQuizScore = function() {
    return this.lastQuizScore;
  };

  PathfinderRuntime.prototype.getQuizAttemptCount = function() {
    return this.quizAttemptCount;
  };

  PathfinderRuntime.prototype.isQuizExhausted = function() {
    var allowed = (this.course.quiz && this.course.quiz.attemptsAllowed) || 0;
    if (allowed === 0) return false; // 0 = unlimited
    return this.quizAttemptCount >= allowed;
  };

  PathfinderRuntime.prototype._renderQuizQuestion = function(obj) {
    var question = this.questionsById[obj.questionId];
    if (!question) return null;
    var self = this;
    var root = document.createElement('div');
    root.setAttribute('data-question-id', question.id);
    // Opt into the design system's quiz card styling (rounded surface,
    // subtle border + shadow). Works in concert with the per-type
    // class applied by _renderObject ("pf-object pf-object-quiz").
    root.className = 'pf-quiz-question';

    // <fieldset><legend> groups the options so a screen reader reads
    // "Question text — option 1, option 2..." instead of an
    // unrelated stem div followed by stray radios.
    var fieldset = document.createElement('fieldset');
    var legend = document.createElement('legend');
    legend.className = 'pf-question-text';
    legend.textContent = this._substitute(String(question.text || ''));
    fieldset.appendChild(legend);

    var listEl = document.createElement('div');
    listEl.className = 'pf-question-options';

    if (question.type === 'multiple_choice' || question.type === 'true_false') {
      var radioName = 'pf-q-' + question.id;
      var opts = question.options || [];
      for (var i = 0; i < opts.length; i++) {
        var opt = opts[i];
        var label = document.createElement('label');
        // Layout comes from .pf-question-options label in the runtime
        // stylesheet — flex row with soft background and hover state.
        var input = document.createElement('input');
        var inputId = 'pf-' + question.id + '-' + opt.id;
        input.type = 'radio';
        input.name = radioName;
        input.value = opt.id;
        input.id = inputId;
        label.setAttribute('for', inputId);
        input.addEventListener('change', (function(qid, oid) {
          return function() { self.quizAnswers[qid] = oid; };
        })(question.id, opt.id));
        label.appendChild(input);
        label.appendChild(document.createTextNode(' ' + (opt.label || opt.text || opt.id)));
        listEl.appendChild(label);
      }
    } else if (question.type === 'multiple_response') {
      var optsM = question.options || [];
      for (var j = 0; j < optsM.length; j++) {
        var optM = optsM[j];
        var labelM = document.createElement('label');
        // See radio/checkbox styling note above — same flex row.
        var inputM = document.createElement('input');
        var inputMId = 'pf-' + question.id + '-' + optM.id;
        inputM.type = 'checkbox';
        inputM.value = optM.id;
        inputM.id = inputMId;
        labelM.setAttribute('for', inputMId);
        inputM.addEventListener('change', (function(qid, oid) {
          return function(e) {
            var arr = self.quizAnswers[qid];
            if (!Array.isArray(arr)) arr = [];
            var idx = arr.indexOf(oid);
            if (e.target.checked && idx < 0) arr.push(oid);
            if (!e.target.checked && idx >= 0) arr.splice(idx, 1);
            self.quizAnswers[qid] = arr;
          };
        })(question.id, optM.id));
        labelM.appendChild(inputM);
        labelM.appendChild(document.createTextNode(' ' + (optM.label || optM.text || optM.id)));
        listEl.appendChild(labelM);
      }
    } else if (question.type === 'fill_blank' || question.type === 'numeric') {
      var input2 = document.createElement('input');
      input2.type = 'text';
      var input2Id = 'pf-' + question.id + '-fill';
      input2.id = input2Id;
      input2.setAttribute('aria-labelledby', legend.id || (legend.id = input2Id + '-label'));
      input2.addEventListener('input', (function(qid) {
        return function(e) { self.quizAnswers[qid] = e.target.value; };
      })(question.id));
      listEl.appendChild(input2);
    } else if (question.type === 'matching') {
      // Matching: one <select> per item; options are the match targets.
      var targets = question.matchTargets || [];
      var items = question.options || [];
      if (!self.quizAnswers[question.id]) self.quizAnswers[question.id] = {};
      for (var mi = 0; mi < items.length; mi++) {
        var mItem = items[mi];
        var mRow = document.createElement('div');
        // Layout comes from .pf-quiz-match-row (flex row, soft surface).
        mRow.className = 'pf-quiz-match-row';
        var mLabel = document.createElement('span');
        mLabel.textContent = mItem.text || mItem.id;
        mRow.appendChild(mLabel);
        var mSel = document.createElement('select');
        mSel.setAttribute('data-item-id', mItem.id);
        var mBlank = document.createElement('option');
        mBlank.value = '';
        mBlank.textContent = '-- Select --';
        mSel.appendChild(mBlank);
        for (var mt = 0; mt < targets.length; mt++) {
          var mOpt = document.createElement('option');
          mOpt.value = targets[mt].id;
          mOpt.textContent = targets[mt].text || targets[mt].id;
          mSel.appendChild(mOpt);
        }
        mSel.addEventListener('change', (function(qid, itemId) {
          return function(e) {
            var map = self.quizAnswers[qid];
            if (typeof map !== 'object' || map === null) map = {};
            map[itemId] = e.target.value;
            self.quizAnswers[qid] = map;
          };
        })(question.id, mItem.id));
        mRow.appendChild(mSel);
        listEl.appendChild(mRow);
      }
    } else if (question.type === 'sequencing') {
      // Sequencing: each option as a moveable item with up/down buttons.
      var seqOpts = (question.options || []).slice();
      var seqIds = seqOpts.map(function(o) { return o.id; });
      self.quizAnswers[question.id] = seqIds;

      var renderSeqItems = function() {
        listEl.innerHTML = '';
        var currentIds = self.quizAnswers[question.id];
        for (var si = 0; si < currentIds.length; si++) {
          var sOpt = seqOpts.find(function(o) { return o.id === currentIds[si]; });
          var sRow = document.createElement('div');
          sRow.setAttribute('data-seq-item', currentIds[si]);
          // Layout comes from .pf-quiz-seq-row (flex row with up/down arrow buttons).
          sRow.className = 'pf-quiz-seq-row';
          var upBtn = document.createElement('button');
          upBtn.type = 'button';
          upBtn.setAttribute('data-action', 'up');
          upBtn.textContent = '\u25B2';
          upBtn.disabled = (si === 0);
          upBtn.addEventListener('click', (function(idx) {
            return function() {
              var arr = self.quizAnswers[question.id];
              if (idx > 0) {
                var tmp = arr[idx - 1];
                arr[idx - 1] = arr[idx];
                arr[idx] = tmp;
                renderSeqItems();
              }
            };
          })(si));
          var downBtn = document.createElement('button');
          downBtn.type = 'button';
          downBtn.setAttribute('data-action', 'down');
          downBtn.textContent = '\u25BC';
          downBtn.disabled = (si === currentIds.length - 1);
          downBtn.addEventListener('click', (function(idx) {
            return function() {
              var arr = self.quizAnswers[question.id];
              if (idx < arr.length - 1) {
                var tmp = arr[idx + 1];
                arr[idx + 1] = arr[idx];
                arr[idx] = tmp;
                renderSeqItems();
              }
            };
          })(si));
          var sLabel = document.createElement('span');
          sLabel.textContent = sOpt ? (sOpt.text || sOpt.id) : currentIds[si];
          sRow.appendChild(upBtn);
          sRow.appendChild(downBtn);
          sRow.appendChild(sLabel);
          listEl.appendChild(sRow);
        }
      };
      renderSeqItems();
    }

    fieldset.appendChild(listEl);
    root.appendChild(fieldset);
    return root;
  };

  PathfinderRuntime.prototype._submitQuiz = function() {
    var quiz = this.course.quiz;
    if (!quiz || !quiz.questions || quiz.questions.length === 0) return;

    if (this.isQuizExhausted()) {
      this._emit('quizattemptsexceeded', {
        attempts: this.quizAttemptCount,
        allowed: quiz.attemptsAllowed,
      });
      return;
    }
    this.quizAttemptCount++;

    var raw = 0;
    var possible = 0;
    for (var i = 0; i < quiz.questions.length; i++) {
      var q = quiz.questions[i];
      possible += (q.points || 0);
      if (this._isCorrect(q, this.quizAnswers[q.id])) {
        raw += (q.points || 0);
      }
    }
    var percent = possible > 0 ? Math.round((raw / possible) * 1000) / 10 : 0;
    var passing = (typeof quiz.passingScore === 'number') ? quiz.passingScore : 0;
    var passed = percent >= passing;
    var score = {
      raw: raw,
      possible: possible,
      percent: percent,
      passed: passed,
      status: passed ? 'passed' : 'failed',
    };
    this.lastQuizScore = score;

    // Forward to LMS adapter if it exposes the SCORM-style helpers.
    if (this.lmsAdapter) {
      try {
        if (typeof this.lmsAdapter.SaveScore === 'function') {
          var scaled = possible > 0 ? raw / possible : 0;
          this.lmsAdapter.SaveScore(raw, 0, possible, scaled);
        }
        if (typeof this.lmsAdapter.SaveCompletion === 'function') {
          this.lmsAdapter.SaveCompletion(passed ? 'passed' : 'failed');
        }
      } catch (e) {
        if (typeof console !== 'undefined' && console.warn) {
          console.warn('[PathfinderRuntime] LMS adapter threw on quiz submit:', e);
        }
      }
    }

    // Persist the new attempt count + score so they survive a session
    // restart — attempt limits otherwise reset on every browser refresh.
    this.saveProgress();

    this._emit('quizcomplete', score);
  };

  PathfinderRuntime.prototype._isCorrect = function(question, response) {
    if (response === undefined || response === null) return false;
    switch (question.type) {
      case 'multiple_choice':
      case 'true_false': {
        var correct = (question.options || []).filter(function(o) { return o.isCorrect; })[0];
        return correct ? correct.id === response : false;
      }
      case 'multiple_response': {
        if (!Array.isArray(response)) return false;
        var correctIds = (question.options || [])
          .filter(function(o) { return o.isCorrect; })
          .map(function(o) { return o.id; })
          .sort();
        var picked = response.slice().sort();
        if (picked.length !== correctIds.length) return false;
        for (var k = 0; k < picked.length; k++) {
          if (picked[k] !== correctIds[k]) return false;
        }
        return true;
      }
      case 'fill_blank': {
        var expected = String(question.correctAnswer || '');
        var actual = String(response);
        if (question.caseSensitive) return actual.trim() === expected.trim();
        return actual.trim().toLowerCase() === expected.trim().toLowerCase();
      }
      case 'numeric': {
        var num = parseFloat(String(response));
        var target = parseFloat(String(question.correctAnswer));
        if (isNaN(num) || isNaN(target)) return false;
        var tol = (typeof question.tolerance === 'number') ? question.tolerance : 0;
        return Math.abs(num - target) <= tol;
      }
      case 'matching': {
        // response is { itemId: targetId, ... }. Check each item's
        // matchTarget against the selected target.
        if (!response || typeof response !== 'object') return false;
        var items = question.options || [];
        for (var mi = 0; mi < items.length; mi++) {
          var mItem = items[mi];
          if (response[mItem.id] !== mItem.matchTarget) return false;
        }
        return true;
      }
      case 'sequencing': {
        // response is an array of option ids in learner order.
        // correctSequence is the expected order.
        if (!Array.isArray(response)) return false;
        var seq = question.correctSequence || [];
        if (response.length !== seq.length) return false;
        for (var si = 0; si < seq.length; si++) {
          if (response[si] !== seq[si]) return false;
        }
        return true;
      }
      default:
        return false;
    }
  };

  global.PathfinderRuntime = PathfinderRuntime;

})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this));
